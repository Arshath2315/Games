import java.util.Scanner;
import java.util.Random;
public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Rock Paper Scissors, Shoot!");
        String[] options ={"Rock","Paper","Scissors"};
        Random random = new Random();
        int values = random.nextInt(options.length); //You want to receive the index amount from 0-2
        String CPU = options[values]; //retrieves string in a randomly generated index from 0-2

do{
    try{
        System.out.println("Choice Option: ");
        String choice = scanner.nextLine();
        if(choice.equals("Rock")){
            System.out.println("You Chose Rock");
            System.out.println("The Computer Chose: " + CPU);
            if(CPU.equals("Paper")){
                System.out.println("You Lose");
                System.out.println("---------------------------------");
            }
            else if(CPU.equals("Scissors")){
                System.out.println("You Win");
                System.out.println("---------------------------------");
            }
            else if(CPU.equals("Rock")){
                System.out.println("It's A tie");
                System.out.println("---------------------------------");
            }
        }
        else if(choice.equals("Paper")){
            System.out.println("You Chose Paper");
            System.out.println("The Computer Chose: " + CPU);
            if(CPU.equals("Paper")){
                System.out.println("It's A tie");
                System.out.println("---------------------------------");
            }
            else if(CPU.equals("Scissors")){
                System.out.println("You Lose");
                System.out.println("---------------------------------");
            }
            else if(CPU.equals("Rock")){
                System.out.println("You Win");
                System.out.println("---------------------------------");
            }
        }
        else if(choice.equals("Scissors")){
            System.out.println("You Chose Scissors");
            System.out.println("The Computer Chose: " + CPU);
            if(CPU.equals("Paper")){
                System.out.println("You Win");
                System.out.println("---------------------------------");
            }
            else if(CPU.equals("Scissors")){
                System.out.println("It's A tie");
                System.out.println("---------------------------------");
            }
            else if(CPU.equals("Rock")){
                System.out.println("You Lose");
                System.out.println("---------------------------------");
            }

        }
        else{
            int[] UserTypingFails = new int[2];
            UserTypingFails[3]=2;
        }
    }
    catch(Exception ex){
        System.out.println("Enter Valid Entries. Rock, Paper or Scissors.");
    }
}while(true);




    }
}