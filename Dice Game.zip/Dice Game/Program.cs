﻿namespace Dice_Game
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random NumberGen = new Random();
            int Roll_1 = 0;
            int Roll_2 = 0;
            int Roll_3 = 0;
            int attempts = 0;

            Console.WriteLine("If 2 Dice out of 3 Roll the Same Amount, You Win\nPress Enter To Roll the Dices:");

                do
            {
                Console.ReadLine();
                Roll_1 = NumberGen.Next(1, 7);
                Console.WriteLine("Dice1: " + Roll_1);
                attempts++;

                Roll_2 = NumberGen.Next(1, 7);
                Console.WriteLine("Dice2: " + Roll_2);
                attempts++;

                Roll_3 = NumberGen.Next(1, 7);
                Console.WriteLine("Dice3: " + Roll_3);
                attempts++;

                if (Roll_1 == Roll_2 && Roll_2 == Roll_3)
                {
                    Console.WriteLine("Woah, You're Extremely Lucky! All 3 dices are the same value");
                    break;
                }

                else if (Roll_1 == Roll_2)
                {
                    Console.WriteLine("Congrats! Dice 2 and Dice 3 were the exact same value");
                    break;
                }

                else if (Roll_2 == Roll_3)
                {
                    Console.WriteLine("Congrats! Dice 1 and Dice 2 were the exact same value");
                    break;

                }




            } while (Roll_1 != 6 || Roll_2 != 6 || Roll_3 != 6);
            { 
    
                Console.WriteLine("It took you " + (attempts / 3) + " attempts");
            }


        }
    }
}