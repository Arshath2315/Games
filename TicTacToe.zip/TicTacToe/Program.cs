﻿using System;

class TicTacToe
{
    static char[] board = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    static char currentPlayer = 'X';
    static int moveCount = 0;

    static void Main()
    {
        int gameStatus = 0; // 0: Ongoing, 1: Win, -1: Draw

        while (gameStatus == 0)
        {
            Console.Clear();
            PrintBoard();
            PlayerMove();
            gameStatus = CheckWin();
            SwitchPlayer();
        }

        Console.Clear();
        PrintBoard();
        if (gameStatus == 1)
        {
            Console.WriteLine($"Player {currentPlayer} wins!");
        }
        else
        {
            Console.WriteLine("It's a draw!");
        }
    }

    static void PrintBoard()
    {
        Console.WriteLine("Tic-Tac-Toe Game");
        Console.WriteLine();
        Console.WriteLine($" {board[0]} | {board[1]} | {board[2]} ");
        Console.WriteLine("---|---|---");
        Console.WriteLine($" {board[3]} | {board[4]} | {board[5]} ");
        Console.WriteLine("---|---|---");
        Console.WriteLine($" {board[6]} | {board[7]} | {board[8]} ");
        Console.WriteLine();
    }

    static void PlayerMove()
    {
        int choice;
        bool validMove = false;

        while (!validMove)
        {
            Console.Write($"Player {currentPlayer}, enter your move (1-9): ");
            if (int.TryParse(Console.ReadLine(), out choice) && choice >= 1 && choice <= 9)
            {
                if (board[choice - 1] != 'X' && board[choice - 1] != 'O')
                {
                    board[choice - 1] = currentPlayer;
                    moveCount++;
                    validMove = true;
                }
                else
                {
                    Console.WriteLine("That spot is already taken. Try again.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a number between 1 and 9.");
            }
        }
    }

    static void SwitchPlayer()
    {
        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }

    static int CheckWin()
    {
        int[][] winningCombinations = new int[][]
        {
            new int[] { 0, 1, 2 },
            new int[] { 3, 4, 5 },
            new int[] { 6, 7, 8 },
            new int[] { 0, 3, 6 },
            new int[] { 1, 4, 7 },
            new int[] { 2, 5, 8 },
            new int[] { 0, 4, 8 },
            new int[] { 2, 4, 6 }
        };

        foreach (var combo in winningCombinations)
        {
            if (board[combo[0]] == board[combo[1]] && board[combo[1]] == board[combo[2]])
            {
                return 1; // Current player wins
            }
        }

        if (moveCount == 9)
        {
            return -1; // Draw
        }

        return 0; // Game is ongoing
    }
}
